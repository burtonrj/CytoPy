# Bubble plots with ability to overlay different metavars or flourochromes
# Downsampled mixed scatterplots with ability to overlay different metavars or flourochromes
# Ability to use any of the dim reduction methods