from cytopy.data.setup import global_init, setup_logs
from cytopy.data.project import Project
from cytopy.tests import assets
from mongoengine.connection import connect, disconnect
from loguru import logger
import argparse
import inspect
import os
# A bokeh server that uses the PolyEditTool to edit Patches on a Hextile plot
ASSET_PATH = inspect.getmodule(assets).__path__[0]
setup_logs()


def test_setup():
    """
    Setup testing environment

    Yields
    -------
    None
    """
    logger.info("Setting up testing environment for interactive gating")
    os.mkdir(f"{os.getcwd()}/cytopy_interactive_test_data")
    logger.info("Connecting to test database")
    connect("test", host="mongomock://localhost", alias="core")
    test_project = Project(project_id="test", data_directory=f"{os.getcwd()}/cytopy_interactive_test_data")
    logger.info("Creating example experiment")
    exp = test_project.add_experiment(experiment_id="test experiment",
                                      panel_definition=f"{ASSET_PATH}/test_panel.xlsx")
    logger.info("Adding example data")
    exp.add_fcs_files(sample_id="test sample",
                      primary=f"{ASSET_PATH}/test.fcs",
                      controls={"CD57": f"{ASSET_PATH}/test_fmo.fcs"},
                      compensate=False)


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description="CytoPy interactive gating tool")
    parser.add_argument("--database",
                        type=str,
                        help="Name of the database to connect")
    args = parser.parse_args()
    logger.info(f"Interactive gating; database = {args.database}")
    if args.database == "test":
        test_setup()
    else:
        global_init(database_name=args.database)
